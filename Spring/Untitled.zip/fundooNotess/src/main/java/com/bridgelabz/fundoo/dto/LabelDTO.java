package com.bridgelabz.fundoo.dto;

public class LabelDTO {

	private String labelName;

	public String getLabelName() {
		return labelName;
	}

	public void setLabelName(String labelName) {
		this.labelName = labelName;
	}
	
}
